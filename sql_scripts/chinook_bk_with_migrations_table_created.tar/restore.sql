--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.16
-- Dumped by pg_dump version 13.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "Chinook";
--
-- Name: Chinook; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "Chinook" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'C';


ALTER DATABASE "Chinook" OWNER TO postgres;

\connect "Chinook"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

--
-- Name: Album; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Album" (
    "AlbumId" integer NOT NULL,
    "Title" character varying(160) NOT NULL,
    "ArtistId" integer NOT NULL
);


ALTER TABLE public."Album" OWNER TO postgres;

--
-- Name: Artist; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Artist" (
    "ArtistId" integer NOT NULL,
    "Name" character varying(120)
);


ALTER TABLE public."Artist" OWNER TO postgres;

--
-- Name: Customer; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Customer" (
    "CustomerId" integer NOT NULL,
    "FirstName" character varying(40) NOT NULL,
    "LastName" character varying(20) NOT NULL,
    "Company" character varying(80),
    "Address" character varying(70),
    "City" character varying(40),
    "State" character varying(40),
    "Country" character varying(40),
    "PostalCode" character varying(10),
    "Phone" character varying(24),
    "Fax" character varying(24),
    "Email" character varying(60) NOT NULL,
    "SupportRepId" integer
);


ALTER TABLE public."Customer" OWNER TO postgres;

--
-- Name: Employee; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Employee" (
    "EmployeeId" integer NOT NULL,
    "LastName" character varying(20) NOT NULL,
    "FirstName" character varying(20) NOT NULL,
    "Title" character varying(30),
    "ReportsTo" integer,
    "BirthDate" timestamp without time zone,
    "HireDate" timestamp without time zone,
    "Address" character varying(70),
    "City" character varying(40),
    "State" character varying(40),
    "Country" character varying(40),
    "PostalCode" character varying(10),
    "Phone" character varying(24),
    "Fax" character varying(24),
    "Email" character varying(60)
);


ALTER TABLE public."Employee" OWNER TO postgres;

--
-- Name: Genre; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Genre" (
    "GenreId" integer NOT NULL,
    "Name" character varying(120)
);


ALTER TABLE public."Genre" OWNER TO postgres;

--
-- Name: Invoice; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Invoice" (
    "InvoiceId" integer NOT NULL,
    "CustomerId" integer NOT NULL,
    "InvoiceDate" timestamp without time zone NOT NULL,
    "BillingAddress" character varying(70),
    "BillingCity" character varying(40),
    "BillingState" character varying(40),
    "BillingCountry" character varying(40),
    "BillingPostalCode" character varying(10),
    "Total" numeric(10,2) NOT NULL
);


ALTER TABLE public."Invoice" OWNER TO postgres;

--
-- Name: InvoiceLine; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."InvoiceLine" (
    "InvoiceLineId" integer NOT NULL,
    "InvoiceId" integer NOT NULL,
    "TrackId" integer NOT NULL,
    "UnitPrice" numeric(10,2) NOT NULL,
    "Quantity" integer NOT NULL
);


ALTER TABLE public."InvoiceLine" OWNER TO postgres;

--
-- Name: MediaType; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."MediaType" (
    "MediaTypeId" integer NOT NULL,
    "Name" character varying(120)
);


ALTER TABLE public."MediaType" OWNER TO postgres;

--
-- Name: Playlist; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Playlist" (
    "PlaylistId" integer NOT NULL,
    "Name" character varying(120)
);


ALTER TABLE public."Playlist" OWNER TO postgres;

--
-- Name: PlaylistTrack; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."PlaylistTrack" (
    "PlaylistId" integer NOT NULL,
    "TrackId" integer NOT NULL,
    id integer NOT NULL
);


ALTER TABLE public."PlaylistTrack" OWNER TO postgres;

--
-- Name: Track; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Track" (
    "TrackId" integer NOT NULL,
    "Name" character varying(200) NOT NULL,
    "AlbumId" integer,
    "MediaTypeId" integer NOT NULL,
    "GenreId" integer,
    "Composer" character varying(220),
    "Milliseconds" integer NOT NULL,
    "Bytes" integer,
    "UnitPrice" numeric(10,2) NOT NULL
);


ALTER TABLE public."Track" OWNER TO postgres;

--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_migrations (
    id integer NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.django_migrations OWNER TO postgres;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.django_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_migrations_id_seq OWNER TO postgres;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.django_migrations_id_seq OWNED BY public.django_migrations.id;


--
-- Name: django_migrations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_migrations ALTER COLUMN id SET DEFAULT nextval('public.django_migrations_id_seq'::regclass);


--
-- Data for Name: Album; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Album" ("AlbumId", "Title", "ArtistId") FROM stdin;
\.
COPY public."Album" ("AlbumId", "Title", "ArtistId") FROM '$$PATH$$/3199.dat';

--
-- Data for Name: Artist; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Artist" ("ArtistId", "Name") FROM stdin;
\.
COPY public."Artist" ("ArtistId", "Name") FROM '$$PATH$$/3200.dat';

--
-- Data for Name: Customer; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Customer" ("CustomerId", "FirstName", "LastName", "Company", "Address", "City", "State", "Country", "PostalCode", "Phone", "Fax", "Email", "SupportRepId") FROM stdin;
\.
COPY public."Customer" ("CustomerId", "FirstName", "LastName", "Company", "Address", "City", "State", "Country", "PostalCode", "Phone", "Fax", "Email", "SupportRepId") FROM '$$PATH$$/3201.dat';

--
-- Data for Name: Employee; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Employee" ("EmployeeId", "LastName", "FirstName", "Title", "ReportsTo", "BirthDate", "HireDate", "Address", "City", "State", "Country", "PostalCode", "Phone", "Fax", "Email") FROM stdin;
\.
COPY public."Employee" ("EmployeeId", "LastName", "FirstName", "Title", "ReportsTo", "BirthDate", "HireDate", "Address", "City", "State", "Country", "PostalCode", "Phone", "Fax", "Email") FROM '$$PATH$$/3202.dat';

--
-- Data for Name: Genre; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Genre" ("GenreId", "Name") FROM stdin;
\.
COPY public."Genre" ("GenreId", "Name") FROM '$$PATH$$/3203.dat';

--
-- Data for Name: Invoice; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Invoice" ("InvoiceId", "CustomerId", "InvoiceDate", "BillingAddress", "BillingCity", "BillingState", "BillingCountry", "BillingPostalCode", "Total") FROM stdin;
\.
COPY public."Invoice" ("InvoiceId", "CustomerId", "InvoiceDate", "BillingAddress", "BillingCity", "BillingState", "BillingCountry", "BillingPostalCode", "Total") FROM '$$PATH$$/3204.dat';

--
-- Data for Name: InvoiceLine; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."InvoiceLine" ("InvoiceLineId", "InvoiceId", "TrackId", "UnitPrice", "Quantity") FROM stdin;
\.
COPY public."InvoiceLine" ("InvoiceLineId", "InvoiceId", "TrackId", "UnitPrice", "Quantity") FROM '$$PATH$$/3205.dat';

--
-- Data for Name: MediaType; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."MediaType" ("MediaTypeId", "Name") FROM stdin;
\.
COPY public."MediaType" ("MediaTypeId", "Name") FROM '$$PATH$$/3206.dat';

--
-- Data for Name: Playlist; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Playlist" ("PlaylistId", "Name") FROM stdin;
\.
COPY public."Playlist" ("PlaylistId", "Name") FROM '$$PATH$$/3207.dat';

--
-- Data for Name: PlaylistTrack; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."PlaylistTrack" ("PlaylistId", "TrackId", id) FROM stdin;
\.
COPY public."PlaylistTrack" ("PlaylistId", "TrackId", id) FROM '$$PATH$$/3208.dat';

--
-- Data for Name: Track; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Track" ("TrackId", "Name", "AlbumId", "MediaTypeId", "GenreId", "Composer", "Milliseconds", "Bytes", "UnitPrice") FROM stdin;
\.
COPY public."Track" ("TrackId", "Name", "AlbumId", "MediaTypeId", "GenreId", "Composer", "Milliseconds", "Bytes", "UnitPrice") FROM '$$PATH$$/3209.dat';

--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_migrations (id, app, name, applied) FROM stdin;
\.
COPY public.django_migrations (id, app, name, applied) FROM '$$PATH$$/3211.dat';

--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 1, true);


--
-- Name: Album PK_Album; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Album"
    ADD CONSTRAINT "PK_Album" PRIMARY KEY ("AlbumId");


--
-- Name: Artist PK_Artist; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Artist"
    ADD CONSTRAINT "PK_Artist" PRIMARY KEY ("ArtistId");


--
-- Name: Customer PK_Customer; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Customer"
    ADD CONSTRAINT "PK_Customer" PRIMARY KEY ("CustomerId");


--
-- Name: Employee PK_Employee; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Employee"
    ADD CONSTRAINT "PK_Employee" PRIMARY KEY ("EmployeeId");


--
-- Name: Genre PK_Genre; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Genre"
    ADD CONSTRAINT "PK_Genre" PRIMARY KEY ("GenreId");


--
-- Name: Invoice PK_Invoice; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Invoice"
    ADD CONSTRAINT "PK_Invoice" PRIMARY KEY ("InvoiceId");


--
-- Name: InvoiceLine PK_InvoiceLine; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."InvoiceLine"
    ADD CONSTRAINT "PK_InvoiceLine" PRIMARY KEY ("InvoiceLineId");


--
-- Name: MediaType PK_MediaType; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."MediaType"
    ADD CONSTRAINT "PK_MediaType" PRIMARY KEY ("MediaTypeId");


--
-- Name: Playlist PK_Playlist; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Playlist"
    ADD CONSTRAINT "PK_Playlist" PRIMARY KEY ("PlaylistId");


--
-- Name: PlaylistTrack PK_PlaylistTrack; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PlaylistTrack"
    ADD CONSTRAINT "PK_PlaylistTrack" PRIMARY KEY (id);


--
-- Name: Track PK_Track; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Track"
    ADD CONSTRAINT "PK_Track" PRIMARY KEY ("TrackId");


--
-- Name: django_migrations django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: IFK_AlbumArtistId; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IFK_AlbumArtistId" ON public."Album" USING btree ("ArtistId");


--
-- Name: IFK_CustomerSupportRepId; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IFK_CustomerSupportRepId" ON public."Customer" USING btree ("SupportRepId");


--
-- Name: IFK_EmployeeReportsTo; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IFK_EmployeeReportsTo" ON public."Employee" USING btree ("ReportsTo");


--
-- Name: IFK_InvoiceCustomerId; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IFK_InvoiceCustomerId" ON public."Invoice" USING btree ("CustomerId");


--
-- Name: IFK_InvoiceLineInvoiceId; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IFK_InvoiceLineInvoiceId" ON public."InvoiceLine" USING btree ("InvoiceId");


--
-- Name: IFK_InvoiceLineTrackId; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IFK_InvoiceLineTrackId" ON public."InvoiceLine" USING btree ("TrackId");


--
-- Name: IFK_PlaylistTrackTrackId; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IFK_PlaylistTrackTrackId" ON public."PlaylistTrack" USING btree ("TrackId");


--
-- Name: IFK_TrackAlbumId; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IFK_TrackAlbumId" ON public."Track" USING btree ("AlbumId");


--
-- Name: IFK_TrackGenreId; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IFK_TrackGenreId" ON public."Track" USING btree ("GenreId");


--
-- Name: IFK_TrackMediaTypeId; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IFK_TrackMediaTypeId" ON public."Track" USING btree ("MediaTypeId");


--
-- Name: Album FK_AlbumArtistId; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Album"
    ADD CONSTRAINT "FK_AlbumArtistId" FOREIGN KEY ("ArtistId") REFERENCES public."Artist"("ArtistId");


--
-- Name: Customer FK_CustomerSupportRepId; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Customer"
    ADD CONSTRAINT "FK_CustomerSupportRepId" FOREIGN KEY ("SupportRepId") REFERENCES public."Employee"("EmployeeId");


--
-- Name: Employee FK_EmployeeReportsTo; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Employee"
    ADD CONSTRAINT "FK_EmployeeReportsTo" FOREIGN KEY ("ReportsTo") REFERENCES public."Employee"("EmployeeId");


--
-- Name: Invoice FK_InvoiceCustomerId; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Invoice"
    ADD CONSTRAINT "FK_InvoiceCustomerId" FOREIGN KEY ("CustomerId") REFERENCES public."Customer"("CustomerId");


--
-- Name: InvoiceLine FK_InvoiceLineInvoiceId; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."InvoiceLine"
    ADD CONSTRAINT "FK_InvoiceLineInvoiceId" FOREIGN KEY ("InvoiceId") REFERENCES public."Invoice"("InvoiceId");


--
-- Name: InvoiceLine FK_InvoiceLineTrackId; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."InvoiceLine"
    ADD CONSTRAINT "FK_InvoiceLineTrackId" FOREIGN KEY ("TrackId") REFERENCES public."Track"("TrackId");


--
-- Name: PlaylistTrack FK_PlaylistTrackPlaylistId; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PlaylistTrack"
    ADD CONSTRAINT "FK_PlaylistTrackPlaylistId" FOREIGN KEY ("PlaylistId") REFERENCES public."Playlist"("PlaylistId");


--
-- Name: PlaylistTrack FK_PlaylistTrackTrackId; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PlaylistTrack"
    ADD CONSTRAINT "FK_PlaylistTrackTrackId" FOREIGN KEY ("TrackId") REFERENCES public."Track"("TrackId");


--
-- Name: Track FK_TrackAlbumId; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Track"
    ADD CONSTRAINT "FK_TrackAlbumId" FOREIGN KEY ("AlbumId") REFERENCES public."Album"("AlbumId");


--
-- Name: Track FK_TrackGenreId; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Track"
    ADD CONSTRAINT "FK_TrackGenreId" FOREIGN KEY ("GenreId") REFERENCES public."Genre"("GenreId");


--
-- Name: Track FK_TrackMediaTypeId; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Track"
    ADD CONSTRAINT "FK_TrackMediaTypeId" FOREIGN KEY ("MediaTypeId") REFERENCES public."MediaType"("MediaTypeId");


--
-- PostgreSQL database dump complete
--

